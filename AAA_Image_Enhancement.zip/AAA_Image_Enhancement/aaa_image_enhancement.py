import cv2
import numpy as np
from PIL import Image, ImageEnhance
import os

def enhance_image(image_path, output_path):
    
    # Load the image using OpenCV
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Unable to load image {image_path}")
        return

    # Convert to PIL Image for enhancement
    pil_image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))

    
    enhancer = ImageEnhance.Brightness(pil_image)
    pil_image = enhancer.enhance(1.2)  # Increase brightness by 20%

    enhancer = ImageEnhance.Contrast(pil_image)
    pil_image = enhancer.enhance(1.2)  # Increase contrast by 20%

    
    enhanced_image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

    
    lab = cv2.cvtColor(enhanced_image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    l = clahe.apply(l)

    
    lab[:, :, 0] = l
    enhanced_image = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    
    cv2.imwrite(output_path, enhanced_image)

def main():
    print("Current Working Directory:", os.getcwd())

    input_folder = os.path.join(os.getcwd(), "input_images")
    output_folder = os.path.join(os.getcwd(), "enhanced_images")

    print("Input Folder Path:", input_folder)
    print("Output Folder Path:", output_folder)

    
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print("Created output folder.")

    
    if not os.path.exists(input_folder):
        print(f" Error: Input folder not found at {input_folder}")
        return

    # Process each image
    files_processed = 0
    for filename in os.listdir(input_folder):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
            input_image_path = os.path.join(input_folder, filename)
            output_image_path = os.path.join(output_folder, f"enhanced_{filename}")

            print(f"Processing: {filename} -> {output_image_path}")

            enhance_image(input_image_path, output_image_path)
            files_processed += 1

    if files_processed == 0:
        print("⚠ No images found in input_images folder.")
    else:
        print(f" Processed {files_processed} images successfully!")

if __name__ == "__main__":
    main()

